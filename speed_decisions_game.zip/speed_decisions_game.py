#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# لعبة سرعة القرارات - باستخدام Flask

from flask import Flask, render_template_string, jsonify
import random, webbrowser, threading, time

app = Flask(__name__)

QUESTION_BANK = [
    {"question": "5 + 3 = 8", "answer": True},
    {"question": "10 - 4 = 7", "answer": False}
]

GAME_TEMPLATE = "<h1>لعبة سرعة القرارات</h1>"

@app.route('/')
def game():
    return render_template_string(GAME_TEMPLATE)

@app.route('/api/questions')
def get_questions():
    return jsonify(random.sample(QUESTION_BANK, len(QUESTION_BANK)))

def open_browser():
    time.sleep(1.5)
    webbrowser.open('http://localhost:5000')

if __name__ == '__main__':
    threading.Thread(target=open_browser, daemon=True).start()
    app.run(host='0.0.0.0', port=5000)
